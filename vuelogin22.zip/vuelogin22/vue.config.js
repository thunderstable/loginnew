module.exports = {
  devServer: {
    port: 80
  }
}