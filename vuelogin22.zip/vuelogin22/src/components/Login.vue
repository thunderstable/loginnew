<template>
  <div class="bigscreen">
    <div class="row">
      <div class="col-xl-8 col-lg-8 col-md-6 col-sm-1 col-1 " style=" height:98vh;background-color:	">

        <div class="container mt-5">
          <div class="text-center" style="color:		#505050; font-size:50px;">WATER TREAT</div>
          <div class="text-center" style="color:		#505050; font-size:22px;">บริษัท วอเตอร์ ทรีท จำกัด</div>
        </div>

        <div class="text-center" style="height:55%"> <img
            src="https://firebasestorage.googleapis.com/v0/b/sgroup-f5926.appspot.com/o/images%2Fffff.png?alt=media&token=c7907608-0477-4b35-8f3a-b92342d66eb8"
            style="height:100%" /></div>

        <div class="row justify-content-center">
          <div class="col-7 text-center" style="color:#505050; font-size:16px;">บริษัท วอเตอร์ ทรีท จำกัด
            เราได้วางรากฐานการดูแลระบบการจัดการด้านน้ำเสีย ทั้งในกลุ่มอาคาร ชุมชนและโรงงานอุตสาหกรรม
            เพื่อเป็นผู้เชี่ยวชาญทางด้านสิ่งแวดล้อมอย่างแท้จริง </div>
        </div>

        <!-- <img src="https://itp1.itopfile.com/ImageServer/z_itp_13042021f9nm/0/0/logowatertreatz-z486892891675.webp" /> -->

      </div>
      <div class="col-xl-4 col-lg-4 col-md-6" style="background-color:#e3f2fd;">
        <div class="row justify-content-center">
          <div class="col-md-8">
            <div class="container">
              <div class="text-center ggg" style="height:80px;"> <img
            src="https://itp1.itopfile.com/ImageServer/z_itp_13042021f9nm/0/0/logowatertreatz-z486892891675.webp"
            style="height:100%" /></div>
            <!-- <img class="ggg text-center" src="https://itp1.itopfile.com/ImageServer/z_itp_13042021f9nm/0/0/logowatertreatz-z486892891675.webp" /> -->
              <div class="mt-1"></div>

              <div class="text-center" style="font-size:18px; font-weight:bold;">WATER TREAT LOGIN</div>
              <div class="text-center" style="font-size:14px;">กรอก Username และ Password เพื่อเข้าสู่ระบบ</div>
              <div class="mt-3"></div>
              <Form @submit="handleLogin" :validation-schema="schema">
                <div class="form-group">
                  <label for="username">Username</label>
                  <Field name="username" type="text" class="form-control" />
                  <ErrorMessage name="username" class="error-feedback" />
                </div>
                <div class="form-group">
                  <label for="password">Password</label>
                  <Field name="password" type="password" class="form-control" />
                  <ErrorMessage name="password" class="error-feedback" />
                </div>

                <div class="form-group">
                  <button class="btn btn-primary btn-block" :disabled="loading">
                    <span v-show="loading" class="spinner-border spinner-border-sm"></span>
                    <span>เข้าสู่ระบบ</span>
                  </button>
                </div>

                <div class="form-group">
                  <div v-if="message" class="alert alert-danger" role="alert">
                    {{ message }}
                  </div>
                </div>

                <div class="text-center">หรือ</div>
                <div class="mt-3"></div>
                <div class="form-group">
        
                    <router-link to="/register" class="btn btn-secondary btn-block">
                      <span>ลงชื่อเข้าใช้งาน</span>
                    </router-link>
         
                </div>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div class="smallscreen">
      <div class="row justify-content-center" style="background-color:#e3f2fd;height:98vh">
          <div class="col-md-8">
            <div class="container">
              <div class="text-center ggg2" style="height:80px;"> <img
            src="https://itp1.itopfile.com/ImageServer/z_itp_13042021f9nm/0/0/logowatertreatz-z486892891675.webp"
            style="height:100%" /></div>
            <!-- <img class="ggg text-center" src="https://itp1.itopfile.com/ImageServer/z_itp_13042021f9nm/0/0/logowatertreatz-z486892891675.webp" /> -->
              <div class="mt-1"></div>

              <div class="text-center" style="font-size:18px; font-weight:bold;">WATER TREAT LOGIN</div>
              <div class="text-center" style="font-size:14px;">กรอก Username และ Password เพื่อเข้าสู่ระบบ</div>
              <div class="mt-3"></div>
                <Form @submit="handleLogin" :validation-schema="schema">
                <div class="form-group">
                  <label for="username">Username</label>
                  <Field name="username" type="text" class="form-control" />
                  <ErrorMessage name="username" class="error-feedback" />
                </div>
                <div class="form-group">
                  <label for="password">Password</label>
                  <Field name="password" type="password" class="form-control" />
                  <ErrorMessage name="password" class="error-feedback" />
                </div>

                <div class="form-group">
                  <button class="btn btn-primary btn-block" :disabled="loading">
                    <span v-show="loading" class="spinner-border spinner-border-sm"></span>
                    <span>เข้าสู่ระบบ</span>
                  </button>
                </div>

                <div class="form-group">
                  <div v-if="message" class="alert alert-danger" role="alert">
                    {{ message }}
                  </div>
                </div>

                <div class="text-center">หรือ</div>
                <div class="mt-3"></div>
                <div class="form-group">
        
                    <router-link to="/register" class="btn btn-secondary btn-block">
                      <span>ลงชื่อเข้าใช้งาน</span>
                    </router-link>
         
                </div>
              </Form>
            </div>
          </div>
        </div>
</div>
  <!-- <div class="col-md-12" >
    <div class="card card-container">
      <img
        id="profile-img"
        src="//ssl.gstatic.com/accounts/ui/avatar_2x.png"
        class="profile-img-card"
      />
      <Form @submit="handleLogin" :validation-schema="schema">
        <div class="form-group">
          <label for="username">Username</label>
          <Field name="username" type="text" class="form-control" />
          <ErrorMessage name="username" class="error-feedback" />
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <Field name="password" type="password" class="form-control" />
          <ErrorMessage name="password" class="error-feedback" />
        </div>

        <div class="form-group">
          <button class="btn btn-primary btn-block" :disabled="loading">
            <span
              v-show="loading"
              class="spinner-border spinner-border-sm"
            ></span>
            <span>Login</span>
          </button>
        </div>

        <div class="form-group">
          <div v-if="message" class="alert alert-danger" role="alert">
            {{ message }}
          </div>
        </div>
      </Form>
    </div>
  </div> -->
</template>

<script>
  import {
    Form,
    Field,
    ErrorMessage
  } from "vee-validate";
  import * as yup from "yup";

  export default {
    name: "Login",
    components: {
      Form,
      Field,
      ErrorMessage,
    },
    data() {
      const schema = yup.object().shape({
        username: yup.string().required("Username is required!"),
        password: yup.string().required("Password is required!"),
      });

      return {
        loading: false,
        message: "",
        schema,
      };
    },
    computed: {
      loggedIn() {
        return this.$store.state.auth.status.loggedIn;
      },
    },
    created() {
      if (this.loggedIn) {
        this.$router.push("/profile");
      }
    },
    methods: {
      handleLogin(user) {
        this.loading = true;

        this.$store.dispatch("auth/login", user).then(
          () => {
            this.$router.push("/profile");
          },
          (error) => {
            this.loading = false;
            this.message =
              (error.response &&
                error.response.data &&
                error.response.data.message) ||
              error.message ||
              error.toString();
          }
        );
      },
    },
  };
</script>

<style scoped>
  div.bigscreen {
    padding: 0px;
  }
  @media screen and (max-width: 1024px) {
    div.bigscreen {
      display: none;
    }
  }

  div.smallscreen {
    padding: 20px;
  }
  @media screen and (min-width: 1024px) {
    div.smallscreen {
      display: none;
    }
  }

  label {
    display: block;
    margin-top: 10px;
  }

  .card-container.card {
    max-width: 350px !important;
    padding: 40px 40px;
  }

  .card {
    background-color: #f7f7f7;
    padding: 20px 25px 30px;
    margin: 0 auto 25px;
    margin-top: 0px;
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .ggg{
    width: auto;
    height: 60px;
    margin-top:50%;
  }
  .ggg2{
    width: auto;
    height: 60px;
    margin-top:30%; 
  }

  .profile-img-card {
    width: 96px;
    height: 96px;
    margin: 0 auto 10px;
    display: block;
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    border-radius: 50%;
  }

  .error-feedback {
    color: red;
  }
</style>